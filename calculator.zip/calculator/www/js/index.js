 var sss =document.getElementById("id1")
 function abc(obj)
{
var x=obj.innerHTML;
if(x=="=")
    {
        sss.innerHTML=eval(sss.innerHTML)
    }
    else if(x=="AC")
        {
            sss.innerHTML="0"
        }
    else
        {
            if(sss.innerHTML=="0")
                {
                    sss.innerHTML=x;    
                }
            else
                {
                    sss.innerHTML=sss.innerHTML+x;
                }
        }
    }    
